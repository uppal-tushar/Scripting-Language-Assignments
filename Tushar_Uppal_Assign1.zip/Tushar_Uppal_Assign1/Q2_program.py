print("="*20)
print("Shipping Calculator\n\n")
print("="*20) #this print is used to print ********* upto 20 times

_continue_ = True  #using continue for repeating the code in the loop again and again 

while _continue_:
  coto = float(input("Cost of items ordered: "))
  shipping_cost = None 
 #adding all the condition according to the question
  if coto < 0:
     print("You must enter a positive number. Please try again")
     continue
  elif coto >0 and coto <30.00:
     shipping_cost = 5.95
  elif coto >=30.00 and coto <= 49.99:
     shipping_cost = 7.95
  elif coto >=50.00 and coto <=74.99:
     shipping_cost = 9.95
  else:
     shipping_cost = 0.0

  print("Shipping cost: ", shipping_cost)
  print("Total cost: ", coto + shipping_cost, "\n")
  _continue_ = True if input("Continue? (y/n)").lower() == "y" else False
  print("="*20)

print("Bye!")
