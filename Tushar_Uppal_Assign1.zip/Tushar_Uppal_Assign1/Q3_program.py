import random # import random .It will return random numbers 
def roll_dice():
    return random.randint(1, 6)

def main():
    print("Dice Roller")
    roll = True if input("Roll the dice? (y/n): ").lower() == "y" else False
    while roll:
        die1 = roll_dice()
        die2 = roll_dice()
        
        total = die1 + die2
        print("Die 1 :", die1)
        print("Die 2 :", die2)
        print("Total: ", total)
        if die1 == die2 == 1:
            print("Snale eyes!\n")
        elif die1 == die2 == 6:
            print("Boxcars\n")
        else:
            print("\n")
        roll = True if input("Roll the dice? (y/n): ").lower() == "y" else False

if __name__=="__main__":
    main()