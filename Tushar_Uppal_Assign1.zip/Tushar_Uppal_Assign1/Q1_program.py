
print("Pay Check Calculator\n\n")
hours_worked=float(input("Hours Worked: ")) #taking input for hours worked
hourly_pr=float(input("Hourly Pay Rate: ")) #taking input for hourly pay rate
gross_pay= hours_worked * hourly_pr
tax_rate=18  #set the tax rate according to the demand of the question
tax_amount= gross_pay*(tax_rate/100)
take_home_pay = gross_pay-tax_amount

print ( "\n\nGross Pay: " , round(gross_pay,2))
print ("Tax Rate : ", tax_rate,"%")
print("Tax Amount: ",round(tax_amount,2) )
print("Take Home Pay: ",round(take_home_pay,2))

#print(hourly_pr)