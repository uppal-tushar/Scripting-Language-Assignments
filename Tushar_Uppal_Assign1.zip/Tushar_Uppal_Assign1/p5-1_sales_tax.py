#!/usr/bin/env python3

TAX = 0.06

def sales_tax(total): #semicolumn 
    sales_tax = total * TAX #use TAX instead of tax
    return sales_tax #return sales_tax instead of total

def main():
    print("Sales Tax Calculator\n")
    total = float(input("Enter total: "))
    total_after_tax = round(total + sales_tax(total), 2)
    print("Total after tax: ", total_after_tax)
    
if __name__ == "__main__":
    main()
