class prime_number_checker:
    
    def __init__(self):
        self.number = None
        self.factors = ['1']
    
    def enter_number(self):
        self.number = int(input("\nPlease enter an integer between 1 and 5000: "))
        
    def reset(self):
        self.number = None
        self.factors = ['1']
        
    def _continue_(self):
        
        while True:
            stop = input("Try again? (y/n): ")
            if stop.lower() == "y".lower():
                return False
            elif stop.lower() == 'n'.lower():
                return True
            else:
                print("Please enter a valid input (y/n)")
    
    def check(self):
        is_prime_number = True
        # prime numbers are greater than 1
        if self.number >= 1 and self.number <=5000:
            # check for factors
            for i in range(2, self.number):
                if (self.number % i) == 0:
                    # if factor is found, set flag to True
                    self.factors.append(str(i))
                    is_prime_number = False
                    # break out of loop
        if not is_prime_number:
            self.factors.append(str(self.number))
        return is_prime_number
    
    def run(self):
        print("Prime Number Checker")
        
        stop = False
        
        while not stop:
            self.enter_number()
            is_prime_number = self.check()
            if is_prime_number:
                print(f"{self.number} is a prime number")
            else:
                print(str(self.number) + " is Not a prime number.\nIt has " + str(len(self.factors))+  " factors: " + ' '.join(self.factors) + "\n")
            
            self.reset()
            stop = self._continue_()
    

if __name__=="__main__":
    prime_number_checker().run()
    print("\nBye!")