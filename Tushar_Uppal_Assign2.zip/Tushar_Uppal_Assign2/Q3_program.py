class quater_sales:
    
    def __init__(self):
        self.quater_sales = []
        self.number_of_quaters = 4
        self.total = None
        self.average_quater = None
        self.lowest_quater = None
        self.highest_quater = None
    def enter_quaterly_sales(self):
        for i in range(self.number_of_quaters):
            self.quater_sales.append(float(input(f"Enter sales for Q{i+1}: ")))
#             quater_sales.append(float(input("Enter sales for Q2: ")))
#             quater_sales.append(float(input("Enter sales for Q3: ")))
#             quater_sales.append(float(input("Enter sales for Q4: ")))
    def get_total(self):
        self.total = round(sum(self.quater_sales),2)
        return self.total
    
    def get_average_quater_sales(self):
        self.average_quater = round(self.total/self.number_of_quaters,2)
        return self.average_quater
    
    def get_lowest_quater_sales(self):
        self.lowest_quater = round(min(self.quater_sales),2)
        return self.lowest_quater
    
    def get_highest_quater_sales(self):
        self.highest_quater = round(max(self.quater_sales),2)
        return self.highest_quater
print("The Quarterly Sales program\n")
quater_sales = quater_sales()
quater_sales.enter_quaterly_sales()

print("\nTotal:          ", quater_sales.get_total())
print("Average Quater: ",quater_sales.get_average_quater_sales())
print("Lowest Quater:  ", quater_sales.get_lowest_quater_sales())
print("Highest Quater: ", quater_sales.get_highest_quater_sales())
