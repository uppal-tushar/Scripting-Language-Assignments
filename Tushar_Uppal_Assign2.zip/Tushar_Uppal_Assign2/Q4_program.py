import random


class TicTacToe:

    def __init__(self):
        self.board = []

    def create_board(self):
        for i in range(3):
            row = []
            for j in range(3):
                row.append(' ')
            self.board.append(row)

    def fix_spot(self, row, col, player):
        self.board[row][col] = player

    def is_player_win(self, player):
        win = None

        n = len(self.board)

        # checking rows
        for i in range(n):
            win = True
            for j in range(n):
                if self.board[i][j] != player:
                    win = False
                    break
            if win:
                return win

        # checking columns
        for i in range(n):
            win = True
            for j in range(n):
                if self.board[j][i] != player:
                    win = False
                    break
            if win:
                return win

        # checking diagonals
        win = True
        for i in range(n):
            if self.board[i][i] != player:
                win = False
                break
        if win:
            return win

        win = True
        for i in range(n):
            if self.board[i][n - 1 - i] != player:
                win = False
                break
        if win:
            return win
        return False

        for row in self.board:
            for item in row:
                if item == ' ':
                    return False
        return True

    def is_board_filled(self):
        for row in self.board:
            for item in row:
                if item == ' ':
                    return False
        return True

    def swap_player_turn(self, player):
        return 'X' if player == 'O' else 'O'

    def show_board(self):
        for row in self.board:
            for i in range(3):
                if i==0:
                    print("+---", end = "+")
                else:
                    print("---", end = "+")
            print()
            print("|", end="")
            for item in row:
                print(" "+ item, end=" |")
            print()
        for i in range(3):
            if i==0:
                print("+---", end = "+")
            else:
                print("---", end = "+")
        print("\n")
        
    def start(self):
        self.create_board()
        self.show_board()

        player = 'X' 
        while True:
            print(f"{player}'s turn")

            # taking user input
            row = int(input("Pick a row (1, 2, 3): "))
            col = int(input("Pick a column (1, 2, 3): "))
            print()

            # fixing the spot
            self.fix_spot(row - 1, col - 1, player)
            
            self.show_board()

            # checking whether current player is won or not
            if self.is_player_win(player):
                print(f"{player} wins!")
                break

            # checking whether the game is draw or not
            if self.is_board_filled():
                print("Match Draw!")
                break

            # swapping the turn
            player = self.swap_player_turn(player)

        # showing the final view of board
        print()



# starting the game
print("Welcome to Tic Tac Toe")
print()
tic_tac_toe = TicTacToe()
tic_tac_toe.start()
print("Game over!")