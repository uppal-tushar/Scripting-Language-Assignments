class wizard_inventory:
    
    def __init__(self):
        print("The Wizard Inventory program\n")
        self.capacity = 4
        self.items = ["wooden staff", "wizard hat", "cloth shoes"]
        self.commands = {
            "show": "Show all items",
            "grab": "Grab an item",
            "edit": "Edit an item",
            "drop": "Drop and item",
            "exit": "Exit program"
        }
        
    def command_menu(self):
        print("COMMAND MENU ")
        for keys in self.commands:
            print(f"{keys} - {self.commands[keys]}")
    
    def grab(self):
        if len(self.items) < self.capacity:
            item = input("Name: ")
            self.items.append(item)
            print(f"{item} was added")
        else:
            print("You can't carry any more items. Drop something first.")
    
    def show(self):
        for idx, item in enumerate(self.items):
            print(f"{idx+1}. {item}")
    
    def edit(self):
        number = int(input("Number: "))
        if number-1 <= len(self.items):
            self.items[number-1] = input("Updated name: ")
            print(f"Items number {number} was updated.")
        else:
            print("Please enter a valid number.")
    
    def drop(self):
        number = int(input("Number: "))
        if number-1 <= len(self.items):
            item = self.items[number-1]
            self.items.remove(item)
            print(f"{item} was dropped.")
        else:
            print("Please enter a valid number.")

if __name__=="__main__":
    wizard_inventory = wizard_inventory()
    wizard_inventory.command_menu()
    while True:
        command = input("\nCommand: ")
        if command.lower() == "show":
            wizard_inventory.show()
        elif command.lower() == "grab":
            wizard_inventory.grab()
        elif command.lower() == "edit":
            wizard_inventory.edit()
        elif command.lower() == "drop":
            wizard_inventory.drop()
        elif command.lower() == "exit":
            # On exit we will delete the object created for the inventory
            # so after exit this object is deleted and with that all the
            # changed will be lost.
            del(wizard_inventory)
            break
        else:
            print("Enter a valid command.")
            wizard_inventory.command_menu()
    print("\nBye!")
