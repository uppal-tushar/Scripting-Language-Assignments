class Person:
  def __init__(self, first_name, last_name, email):
    self.first_name = first_name
    self.last_name = last_name
    self.email = email
  
  def get_name(self):
    return self.first_name+self.last_name

  def get_email(self):
    return self.email

class Customer(Person):

  def __init__(self, first_name, last_name, email, number):
    self.number = number
    Person.__init__(self, first_name, last_name, email)

  def get_number(self):
    return self.number

class Employee(Person):

  def __init__(self, first_name, last_name, email, ssn):
    self.ssn = ssn
    Person.__init__(self, first_name, last_name, email)

  def get_ssn(self):
    return self.ssn

def display(obj):
  is_customer = isinstance(obj, Customer)
  if is_customer:
    print("\nCUSTOMER")
    print("Name: {:<10}".format(obj.get_name()))
    print("Email: {:<10}".format(obj.get_email()))
    print("Number: {:<10}".format(obj.get_number()))
  else:
    print("\nEMPLOYEE")
    print("Name: {:<10}".format(obj.get_name()))
    print("Email: {:<10}".format(obj.get_email()))
    print("SSN: {:<10} ".format(obj.get_ssn()))
def main():

  print("Customer/Employee Data Entry")
  is_customer = None
  while True:

    is_customer = True if input("Customer or employee? (c/e): ")== "c" else False

    print("\nDATA ENTRY")
    first_name, last_name, email = input("First Name: "), input("Last Name: "), \
                      input("Email: ")
    obj = Customer(first_name, last_name, email, input("Number: ")) \
    if is_customer else Employee(first_name, last_name, email, input("SSN: "))
    
    display(obj)
    continue_ = input("Continue?  ()y/n):")
    if continue_ == 'n':
      break

  print("Bye!")

if __name__ == "__main__":
  main()