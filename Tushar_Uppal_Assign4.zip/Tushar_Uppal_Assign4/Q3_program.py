import csv
 

class Customer:
  def __init__(self, firstName, lastName, company, address, city, state, zip):
    self.firstName = firstName
    self.lastName = lastName
    self.company = company
    self.address = address
    self.city = city
    self.state = state
    self.zip = zip

  def get_name(self):
    return self.firstName + " " + self.lastName

  def get_address(self):
    if self.company != '':
      return self.company + "\n" + self.address + "\n" + self.city + ", "\
      + self.state + " " + self.zip
    else:
      return self.address + "\n" + self.city + ", " + self.state + " " + self.zip

  def print_d(self):
    print(self.firstName)
    print(self.lastName)
    print(self.company)
    print(self.address)
    print(self.city)
    print(self.state)
    print(self.zip)

def display(customer):
  # customer.print_d()
  print("\n" + customer.get_name() + "\n" + customer.get_address())

def main():
  print("Customer Viewer")
  # opening the CSV file
  file_path = "D:\scripting language\Tushar_Uppal_Assign4\customers.csv"
  data = dict()
  with open(file_path, mode ='r')as file:
    

    csvFile = csv.reader(file)
    is_header = True
    for line in csvFile:
      if is_header:
        is_header = False
        continue
      data[int(line[0])] = Customer(line[1], line[2], line[3], line[4], line[5],\
                               line[6], line[7])
                               

  while True:    
    id = int(input("\nEnter Customer ID: "))

    if id in data.keys():
      display(data[id])
    else:
      print("\nNo customer with that ID.")

    continue_ = input("\nContinue? (y/n): ")

    if continue_ == "n":
      break
  print("\nBye!")

if __name__ == "__main__":
  main()