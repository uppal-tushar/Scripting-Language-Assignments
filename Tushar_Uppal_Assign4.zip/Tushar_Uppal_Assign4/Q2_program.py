import random

class clist:
  def __init__(self):
    self.list_ = []

  def append(self, rand_int):
    self.list_.append(rand_int)

  def get(self):
    return self.list_

class RandomIntList(clist):
  def __init__(self, number_of_elements):
    self.number_of_elements = number_of_elements
    clist.__init__(self)
    for i in range(self.number_of_elements):
      self.append(random.randint(0,100))
    

  def get_summary(self):
    return (self.number_of_elements, sum(self.list_), sum(self.list_)/self.number_of_elements)


def main():

  print("Random Integer List")

  while True:

    int_list = RandomIntList(int(input("\nHow many random intergs should the list contain?: ")))

    count, total, avg = int_list.get_summary()
    print("\nRandom Integers")
    print("===============")
    print("Integers: " + ", ".join(list(map(str, int_list.get()))))
    print("Count: ", count)
    print("Total: ", total)
    print("Avegrage: ", avg)

    continue_ = input("\nContinue? (y/n): ")

    if continue_ == "n":
      break
  print("\nBye!")

if __name__ == "__main__":
  main()