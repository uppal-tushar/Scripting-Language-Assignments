from dataclasses import dataclass


@dataclass
class Product:
    def __init__(self, name="", price=200.0, discountPercent=0):
        self.name = name
        self.price = price
        self.discountPercent = discountPercent

    def getDiscountAmount(self):
        return self.price * self.discountPercent / 100

    def getDiscountPrice(self):
        return self.price - self.getDiscountAmount()

    def getDescription(self):
        return self.name


@dataclass()
class Media(Product):
    def __init__(self, name="", price=200, discountPercent=0, productFormat=""):
        super(Media, self).__init__(name, price, discountPercent)
        self.productFormat = productFormat


@dataclass
class Book(Media):
    def __init__(self, name="", price=200, discountPercent=0, author="", bookFormat=""):
        super(Book, self).__init__(name, price, discountPercent, bookFormat)
        self.author = author

    def getDescription(self):
        return f"{Product.getDescription(self)} by {self.author}"


@dataclass
class Movie(Media):
    def __init__(self, name="", price=200, discountPercent=0, year=0, movieFormat=""):
        super(Movie, self).__init__(name, price, discountPercent, movieFormat)
        self.year = year

    def getDescription(self):
        return f"{Product.getDescription(self)} ({self.year})"


@dataclass()
class Album(Media):

    def __init__(self, name="", price=200.0, discountPercent=0, artist="", musicFormat=""):
        super(Album, self).__init__(name, price, discountPercent, musicFormat)
        self.artist = artist

    def getDescription(self):
        return f"{Product.getDescription(self)} - {self.artist}"
