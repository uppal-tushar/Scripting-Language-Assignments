class Temp:

    def __init__(self):
        self._celsius = 0
        self._fahrenheit = 0

    def setCelsius(self, celsius):
        self._celsius = celsius
        self._fahrenheit = (self._celsius * 9 / 5) + 32

    def setFahrenheit(self, fahrenheit):
        self._fahrenheit = fahrenheit
        self._celsius = (self._fahrenheit - 32) * 5 / 9

    def getCelsius(self):
        return round(self._celsius, 2)

    def getFahrenheit(self):
        return round(self._fahrenheit, 2)


def main():
    t1 = Temp()
    t2 = Temp()
    for temp in range(0, 212, 40):
        t1.setFahrenheit(temp)
        print(temp, "Fahrenheit equals", str(t1.getCelsius()), "Celsius")

    for temp in range(0, 100, 20):
        t2.setCelsius(temp)
        print(temp, "Celsius equals", t2.getFahrenheit(), "Fahrenheit")


if __name__ == "__main__":
    main()
