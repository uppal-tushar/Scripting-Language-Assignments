from temperature import Temp


def display_menu():
    print("The Convert Temperatures program")
    print()
    print("MENU")
    print("1. Fahrenheit to Celsius")
    print("2. Celsius to Fahrenheit")
    print()


def convert_temp():
    option = int(input("Enter a menu option: "))
    if option == 1:
        fe = int(input("Enter degrees Fahrenheit: "))
        t1 = Temp()
        t1.setFahrenheit(fe)
        print("Degrees Celsius:", str(t1.getCelsius()))
    elif option == 2:
        ce = int(input("Enter degrees Celsius: "))
        t2 = Temp()
        t2.setCelsius(ce)
        print("Degrees Fahrenheit:", t2.getFahrenheit())
    else:
        print("You must enter a valid menu number.")


def main():
    display_menu()

    again = "y"
    while again.lower() == "y":
        convert_temp()
        print()
        again = input("Convert another temperature? (y/n): ")
        print()

    print("Bye!")


if __name__ == "__main__":
    main()
