from os.path import exists
import pickle

class bird_counter():
    
    def __init__(self):
        self.birds = dict()
        self.bird_counter_file_name = "bird_counter.txt"
        self.max_length = 0
        print("Bird Counter Program\n")
        print("Enter 'x' to exit\n")
        
    def _input_(self):
        return input("Enter name of bird: ")
    
    def display(self):
        print ("\n{:<{max_length}} {:<5}".format("Name", "Count", max_length = self.max_length))
        print ("="*self.max_length + " " + "="*5)
        for bird in sorted(self.birds.keys()):
             print("{:<{max_length}} {:<5}".format(bird.title(), self.birds[bird], max_length = self.max_length))
    
    def check_prev_data(self):
        file_exists = exists(self.bird_counter_file_name)
        if file_exists:
            with open(self.bird_counter_file_name, "rb") as file:
                self.birds = pickle.load(file)
#             print(self.birds)
            self.set_max_length()
        else:
            print(f"{self.bird_counter_file_name} does not exist")
    
    def write(self):
        with open(self.bird_counter_file_name, 'wb') as file:
            pickle.dump(self.birds, file, protocol=pickle.HIGHEST_PROTOCOL)
    
    def set_max_length(self):
        for bird in self.birds.keys():
            if len(bird) > self.max_length:
                   self.max_length = len(bird)
    
    def run(self):
        self.check_prev_data()
        bird_name = self._input_()
        bird_name_length = len(bird_name)
        while bird_name !="x":
            if bird_name_length > self.max_length:
                print("max_length ", self.max_length)
                print("bird_name_lenght ",  bird_name_length)
                self.max_length = bird_name_length
            
            if bird_name in self.birds.keys():
                self.birds[bird_name] = self.birds[bird_name]  +1
            else:
                self.birds[bird_name] = 1
            bird_name = self._input_()
            bird_name_length = len(bird_name)
            if bird_name == "x" or bird_name == "X":
                break
        self.display()
        self.write()
if __name__=="__main__":
    bird_counter().run()
