class fifa_world_cup():
    
    def __init__(self):
        self.world_cup_winners = dict()
        self.file_name = "world_cup_champions.txt"
        print("FIFA World Cup Winners")
         
    def display(self):
        print ("\n{:<15} {:<5} {:<5}".format("Country", "Wins", "Years"))
        print ("="*7 + " "*9 + "="*4 + " "*2 + "="*5)
        for country in sorted(self.world_cup_winners.keys()):
             print("{:<15} {:<5} {:<5}".format(country.title(), self.world_cup_winners[country]["wins"], ", ".join(sorted(self.world_cup_winners[country]["years"]))))
    
    def analyse_winners(self):
        header_skipped = False
        
        with open(self.file_name) as file:
            for line in file:
                if not header_skipped:
                    header_skipped = True
                    pass
                else:
                    (year, country, coach, captain) = line.split(",")
                    if country not in self.world_cup_winners.keys():
                        self.world_cup_winners[country] = {
                            "wins": 1,
                            "years": [str(year)] 
                        }
                    else:
                        self.world_cup_winners[country]["wins"] = self.world_cup_winners[country]["wins"] + 1
                        self.world_cup_winners[country]["years"].append(str(year))
        self.display()
    
if __name__=="__main__":
    fifa_world_cup().analyse_winners()